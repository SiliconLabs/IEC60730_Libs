var searchData=
[
  ['gpcrc_0',['gpcrc',['../structimc_params__t.html#af5438da098733b9ab06c7e7050a4685a',1,'imcParams_t']]]
];
