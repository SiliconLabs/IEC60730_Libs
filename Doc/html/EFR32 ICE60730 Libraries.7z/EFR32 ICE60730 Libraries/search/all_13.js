var searchData=
[
  ['unused_5fvar_0',['UNUSED_VAR',['../group___i_e_c60730___p_o_s_t.html#ga6e61b3a07893501c121343edf3bfcbd8',1,'iec60730.h']]],
  ['updatecrcparams_5ft_1',['updateCrcParams_t',['../structupdate_crc_params__t.html',1,'']]],
  ['use_5fcrc_5f32_2',['USE_CRC_32',['../group___i_e_c60730___i_n_v_a_r_i_a_b_l_e___m_e_m_o_r_y___test.html#ga4414a2176d756dc1c2ade9b42dad5814',1,'iec60730_invariable_memory.h']]],
  ['use_5fmarchx_3',['USE_MARCHX',['../group___i_e_c60730___v_a_r_i_a_b_l_e___m_e_m_o_r_y___test.html#ga605144ce1d5f7fcbcb75b9b425ebd849',1,'iec60730_variable_memory.h']]]
];
