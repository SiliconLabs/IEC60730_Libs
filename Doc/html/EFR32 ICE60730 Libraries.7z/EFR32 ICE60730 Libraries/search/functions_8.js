var searchData=
[
  ['read_5fram_5farm_5f64_0',['read_ram_arm_64',['../classjlink_1_1_j_link_dll.html#af88d9307a04acd3db22dc0d6efb0a0fd',1,'jlink::JLinkDll']]],
  ['register_5flist_1',['register_list',['../classjlink_1_1_j_link_dll.html#adbd4e5ad4370cb309d9831c45496d005',1,'jlink::JLinkDll']]],
  ['register_5fname_2',['register_name',['../classjlink_1_1_j_link_dll.html#a695eb7e0836b129a64481d4683fea1e7',1,'jlink::JLinkDll']]],
  ['register_5fread_3',['register_read',['../classjlink_1_1_j_link_dll.html#ad6b7786db9051c430a1e4d649e649eb7',1,'jlink::JLinkDll']]],
  ['register_5fwrite_4',['register_write',['../classjlink_1_1_j_link_dll.html#a35f46e5ae53cef7570b252b4e0e04b1e',1,'jlink::JLinkDll']]],
  ['reset_5',['reset',['../classjlink_1_1_j_link_dll.html#a3fc884f8ab28b2ce6b9893198dd62095',1,'jlink::JLinkDll']]]
];
