var searchData=
[
  ['hal_0',['hal',['../structupdate_crc_params__t.html#a34ada0551ae09a366f3ac91bdfe22636',1,'updateCrcParams_t']]],
  ['halted_1',['halted',['../classjlink_1_1_j_link_dll.html#aa6fad9e7e170e3cafbb384f8cf0b4dac',1,'jlink::JLinkDll']]]
];
