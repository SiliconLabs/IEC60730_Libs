var searchData=
[
  ['variable_20memory_20automated_20verification_20tests_0',['Variable Memory Automated Verification Tests',['../group___i_e_c60730___v_a_r_i_a_b_l_e___m_e_m_o_r_y___v_e_r_i_f_i_c_a_t_i_o_n.html',1,'']]],
  ['variable_20memory_20check_1',['Variable Memory Check',['../group___i_e_c60730___v_a_r_i_a_b_l_e___m_e_m_o_r_y___test.html',1,'']]]
];
