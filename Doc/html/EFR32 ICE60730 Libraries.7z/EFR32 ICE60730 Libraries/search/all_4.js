var searchData=
[
  ['dec_5fclassb_5fvars_0',['DEC_CLASSB_VARS',['../group___i_e_c60730___p_o_s_t.html#ga8b1f082b1b96f93a3325897446c18128',1,'iec60730.h']]],
  ['default_5fgprc_1',['DEFAULT_GPRC',['../group___i_e_c60730___i_n_v_a_r_i_a_b_l_e___m_e_m_o_r_y___test.html#ga156dbd14b4ce248fe9c88819982a7a5d',1,'iec60730.h']]]
];
