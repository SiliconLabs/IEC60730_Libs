var searchData=
[
  ['num_5factive_5fbreakpoints_0',['num_active_breakpoints',['../classjlink_1_1_j_link_dll.html#af9a412b31add09389e3481e59ac70264',1,'jlink::JLinkDll']]]
];
